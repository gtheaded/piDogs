const { Router } = require('express');
// Importar todos los routers;
// Ejemplo: const authRouter = require('./auth.js');
const axios = require ('axios');
const { Dog, Temperament } = require('../db.js');
const removeDuplicates = require('./functions.js')
require('dotenv').config();
const {
  API_KEY
} = process.env;
const router = Router();


// Configurar los routers
// Ejemplo: router.use('/auth', authRouter);


//////////////////////FUNCIONES IMPORTANTES//////////////////////////////
const getApiInfo = async () =>{

  const apiUrl = await axios.get('https://api.thedogapi.com/v1/breeds', {
    headers: {
      API_KEY
    }
  });
 /*  console.log(apiUrl.data[0].temperament.slice(',')) */
 
  const apiInfo = await apiUrl.data.map(e=>{
    return {
      name: e.name,
      id: e.id,
      height: e.height.metric,
      weight: e.weight.metric,
      life_span: e.life_span,
      image: e.image.url,
      builtInLocal: false,
      temperament: e.temperament? e.temperament.split(", "):['nada']
    }
  });
 /*  console.log(apiInfo) */
 return apiInfo;
}


const getDbInfo = async () => {
  return await Dog.findAll({
    include: [{
      model: Temperament,
      attributes: ['name'],
      through: {
        attributes: [],
      },
    }]
  })
}


router.get('/test', async (req,res)=>{
  
  const info = await getDbInfo();
  /* console.log(info[0].dataValues.temperaments[0].dataValues.name); */

})



const getAllDogs = async() =>{
  const apiInfo = await getApiInfo();
  const dbInfo = await getDbInfo();
  const infoTotal = apiInfo.concat(dbInfo); 
  /* const infoTotal = [...apiInfo,...dbInfo]; */
 
  return infoTotal;
}


/////////////////////////////////RUTAS//////////////////////////////////

/////////////GET
//Seria mejor hacerlo con findByPk por un tema de performance. Ver de cambiarlo si hay tiempo.
router.get('/dogs/:idRaza', async (req,res)=>{
  const infoTota = await getAllDogs();

  const infoIdRaza = await infoTota.filter(e=> e.id.toString() === req.params.idRaza);
  if(infoIdRaza.length>0) return res.json(infoIdRaza);
  return res.send('No hay una raza asociada a ese ID');
})




router.get('/dogs',async (req,res)=>{
 /*  res.setHeader('content-type', 'application/json'); */
  const name = req.query.name;
  const dogs = await getAllDogs();
  if(name){
    const resultado = await dogs.filter(e=>e.name.toLowerCase().includes(name.toLowerCase()));
    if(resultado.length===0){
      return res.send('No se ha encontrado información para esa raza.');
    }
    return res.send(resultado);
  }
return res.send(dogs)
})

router.get('/temperaments', async (req,res)=>{
  const todo = await getAllDogs();
  const temperamentos = todo.map(e=>{
    return e.temperament
  })
  const unicos = await removeDuplicates(temperamentos.flat(),'nada');
  const objectUnicos = unicos.map(e=>{
    return {
      name: e
    }
  })
 /*  Temperament.bulkCreate(objectUnicos);
  res.send('ok'); */
  objectUnicos.forEach(e=>{
    Temperament.findOrCreate({
      where: {name: e.name}
    })
  })
  const allTemperaments = await Temperament.findAll();
  res.send(allTemperaments);
})

router.get('/downloadedTemperaments', async (req,res)=>{
  const temperamentsInDb = await Temperament.findAll();
  res.send(temperamentsInDb);
})





///////////////POST
router.post('/dogs', async (req,res)=>{
  const {name, height,weight,life_span,temperament} = req.body;
  //AGREGAR VALIDACION POR TIPO DE DATOS
  if(!name || !height || !weight){
    return res.send('datos insuficientes para la creacion de la raza');
  }
  try{
  
  const newDog = await Dog.create({
    name,
    height,
    weight,
    life_span: life_span?life_span:"No hay datos de life_span"
  })


  const idTemp = await Temperament.findAll({
    where: {
      name:temperament
    }
  })

  
  newDog.addTemperament(idTemp);
  return res.send(newDog);
}catch(error){
  res.send('ha ocurrido algun problema');
}
  

})



module.exports = router;

  /* URLs importantes */
  /* const apiUrl = await axios.get('https://api.thedogapi.com/v1/breeds', { */
  /* const apiUrl = await axios.get('https://api.thedogapi.com/v1/breeds/search?q=Azawakh', { */
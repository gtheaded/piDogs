
module.exports =  (array, specialWord) => {
  const unicos = [];
  array.forEach(e=>{
  
    if(e===specialWord || unicos.includes(e)){
  
    } else{
      unicos.push(e);
    }
  })

  return unicos;

}


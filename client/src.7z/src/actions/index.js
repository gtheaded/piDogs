import axios from 'axios';

export function getDogs(){
  return async function(dispatch){
    var json = await axios ("http://localhost:3001/dogs", {});
    
    return dispatch({
      type: 'GET_DOGS',
      payload: json.data
    })
  }
}

export function getTemperaments(){
  return async function(dispatch){
    var json = await axios ("http://localhost:3001/downloadedTemperaments", {});
    
    return dispatch({
      type: 'GET_TEMPERAMENTS',
      payload: json.data
    })
  }
}

export function filterByTemperament(payload){
  return {
    type:'FILTER_BY_TEMPERAMENT',
    payload
  }
}

export function filterCreated(payload){
  return {
    type: "FILTER_CREATED",
    payload
  }
}

export function orderByName(payload){
  console.log(payload)
  return {
    type: 'ORDER_BY_NAME',
    payload
  }
}

/* export const getHouse = (id) => dispatch => {
  return fetch('http://localhost:3001/houses/'+ id)
  .then(r => r.json())
  .then(json => {
    dispatch({type: "GET_HOUSE", payload:json})
  })
}; */
import './App.css';
import { Route } from "react-router-dom";
import LandingPage from './components/Landing';
import Home from './components/Home';
/* import Houses from './components/Houses/Houses.jsx';
import Nav from './components/Nav/Nav.jsx';
import HouseDetail from './components/HouseDetail/HouseDetail.jsx';
import CreateHouse from './components/CreateHouse/CreateHouse.jsx'; */

/* function App() {
  return (
    <div className="App">
      <Nav/>
      <Route exact path='/'><Houses/></Route>
      <Route exact path='/houses/:houseId' component={HouseDetail}></Route>
      <Route exact path='/house/create'><CreateHouse/></Route>
    </div>
  );
}

export default App;
 */




function App() {
  return (
    <div className="App">
      <Route exact path = '/'>
        <LandingPage/>
      </Route>
      <Route exact path = '/home'>
        <Home/>
      </Route>
    </div>
  );
}

export default App;
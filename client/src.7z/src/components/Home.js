import React from 'react';
import { useEffect, useState} from 'react';
import { useDispatch, useSelector} from 'react-redux';
import { filterByTemperament, filterCreated, getDogs, getTemperaments, orderByName } from '../actions';
import { Link } from 'react-router-dom';
import Card from './Card';
import Paginado from './Paginado';


const Home  =  (props) =>{
  const dispatch = useDispatch();
  const allDogs = useSelector ((state) => state.dogs)
  const allTemperaments = useSelector ((state)=> state.temperaments)
  
  //Paginado
  const [currentPage, sectCurrentPage] = useState(1);
  const [dogsPerPage, setDogsPerPage] = useState(8);
  const [refresher, setRefresher] = useState(true);
  const indexOfLastDog = currentPage * dogsPerPage;
  const indexOfFirstDog = indexOfLastDog - dogsPerPage;
  const currentDogs = allDogs.slice(indexOfFirstDog,indexOfLastDog);


  const paginado = (pageNumber) =>{
    sectCurrentPage(pageNumber); 
  }




  useEffect(()=>{
    dispatch(getDogs()) //esto ejecuta lo que devuelva getDogs pasandole como argumento dispatch.
    dispatch(getTemperaments());
    
},[dispatch])

/* const renderedList =  allDogs && allDogs.map(e=>{
  return <Card name={e.name} weight={e.weight} id={e.id} image={e.image} temperament={e.temperament}/>
}) */

const renderedList =  currentDogs && currentDogs.map(e=>{
 
  return <Card key={e.id} name={e.name} weight={e.weight} id={e.id} image={e.image} temperament={e.temperament}/>
})

const renderedTemperaments = allTemperaments && allTemperaments.map(e=>{
  return <option value={e.name}>{e.name}</option>
})


const handleClick = (e) => {
  e.preventDefault();
  dispatch(getDogs());
}

const handleSelectTemperament = (e)=>{
  dispatch(filterByTemperament(e.target.value));
}
 
const handleFilterCreated = (e)=>{
  dispatch(filterCreated(e.target.value));
}

const handleSort = (e)=>{
  dispatch(orderByName(e.target.value));
  sectCurrentPage(1);
  setRefresher(!refresher);


}

return (
  <div>
    <Link to = {'/dog'}>Crear una raza</Link>
    <h1>Pagina de Perros</h1>
    <button onClick={(e)=>handleClick(e)}>
      refresh
    </button>
    <div>
    <select onChange={(e)=>handleSort(e)}>
        <option value = 'asc' >Ascendente</option> {/* por orden alfabetico y peso */}
        <option value = 'desc' >Descendente</option>          
      </select>
      <select onChange= {(e)=>handleSelectTemperament(e)}>
      {renderedTemperaments}
      </select>
      <select onChange={(e)=>handleFilterCreated(e)}>
      
        <option value = 'all' >Todos</option>       
        <option value = 'created' >Creados</option>
        <option value = 'existente' >Existente</option> {/* ver en donde poner la seleccion de temperamento */}         
      </select>
      <div>
      <Paginado dogsPerPage={dogsPerPage}  allDogs={allDogs.length} paginado={paginado}></Paginado>
      </div>
     {renderedList}

 {/*  {
    allDogs && allDogs.map(e=>{
      
      return <Card image={e.img} name={e.name} temperament={e.temperament} weight={e.weight}/>
    })
  } */}
    </div>
  </div>
)
} 



export default Home;


/* const Home = () =>{

  const dispatch = useDispatch;
  const allDogs = useSelector ((state) => state.dogs)

  React.useEffect(()=>{
    dispatch(getDogs())
  },[]);

  function handleClick(e){
    e.preventDefault();
    dispatch(getDogs());

  }

  return (
    <div>
      <Link to = {'/dog'}>Crear una raza</Link>
      <h1>Pagina de Perros</h1>
      <button handleClick ={(e)=>handleClick(e)}>
        refresh
      </button>
      <div>
        <select>
          <option value = 'asc' >Ascendente</option>
          <option value = 'desc' >Descendente</option>          
        </select>
        <select>
          <option value = 'all' >Todos</option>
          <option value = 'created' >Creados</option>
          <option value = 'existente' >Existente</option>          
        </select>
    {
      allDogs && allDogs.map(e=>{
        return <Card image={e.img} name={e.name} temperament={e.temperament} weight={e.weight}/>
      })
    }
      </div>
    </div>
  )
}

export const mapDispatchToProps = (dispatch) => {
  return {
      getDogs: () => dispatch(getDogs())
  }
};
export default connect(null, mapDispatchToProps)(Home);

 */


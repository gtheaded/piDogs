import React from 'react'

function Card(props){
  return ( 
  <div>
      <div>
      <h2>{props.name}</h2>
      </div>
      <div>
      <img src={props.image} alt={props.id}></img>
      </div>
      <div>
        {props.weight}
      </div>
      <div>
        {props.temperament}
      </div>
  </div>
  )
}

export default Card;